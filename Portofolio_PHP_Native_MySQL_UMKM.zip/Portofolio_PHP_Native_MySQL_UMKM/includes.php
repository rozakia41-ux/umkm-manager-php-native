<?php
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
function auth(){if(empty($_SESSION['uid'])){header('Location: login.php');exit;}}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_csrf(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(403);exit('Invalid request');}}
function header_html($title){echo '<!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).'</title><link rel="stylesheet" href="assets/style.css"><header><b>UMKM<span>Manager</span></b><nav><a href="index.php">Dashboard</a><a href="products.php">Produk</a><a href="sales.php">Penjualan</a><a href="logout.php">Keluar</a></nav></header><main>';}
function footer_html(){echo '</main><footer>Demo portofolio PHP Native + MySQL • Data fiktif</footer></html>';}
