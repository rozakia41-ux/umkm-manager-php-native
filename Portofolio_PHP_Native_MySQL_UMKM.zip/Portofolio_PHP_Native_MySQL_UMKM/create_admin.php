<?php
require 'config/database.php';
$q=$pdo->prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)');
try{$q->execute(['Administrator','admin@example.com',password_hash('GantiPassword123!',PASSWORD_DEFAULT)]);echo 'Admin dibuat. Login admin@example.com / GantiPassword123! Hapus file create_admin.php setelah ini.';}catch(Throwable $e){echo 'Admin mungkin sudah ada. Hapus file ini setelah setup.';}
