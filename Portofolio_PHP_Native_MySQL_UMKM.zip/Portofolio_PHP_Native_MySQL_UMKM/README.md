# UMKMManager — Portofolio PHP Native + MySQL

Aplikasi demo portofolio (bukan proyek klien) dengan data contoh/fiktif.

## Fitur
- Login admin dengan `password_hash()` dan `password_verify()`
- Dashboard ringkasan produk, stok, transaksi, dan omzet
- CRUD produk
- Catat penjualan dan stok berkurang otomatis
- PDO prepared statements, CSRF token, session regeneration, dan output escaping
- Tampilan responsif

## Instalasi XAMPP
1. Ekstrak folder ke `htdocs`.
2. Import `install.sql` melalui phpMyAdmin.
3. Sesuaikan `config/database.php` jika username/password MySQL berbeda.
4. Buka `http://localhost/Portofolio_PHP_Native_MySQL_UMKM/create_admin.php` satu kali.
5. Login melalui `login.php` dengan:
   - Email: `admin@example.com`
   - Password awal: `GantiPassword123!`
6. Hapus `create_admin.php` setelah admin dibuat dan ganti password awal sebelum demo online.

## Catatan
Ini contoh portofolio latihan, bukan klaim proyek klien dan belum diaudit untuk produksi. Uji di komputer sendiri, isi data dummy, dan ambil screenshot Dashboard, Produk, serta Penjualan untuk ditampilkan ke calon klien.
